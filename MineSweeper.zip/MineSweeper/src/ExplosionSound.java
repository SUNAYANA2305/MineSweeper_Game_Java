

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.net.URL;

//sound effect calss
public final class ExplosionSound {
	
	public static void play(URL fileURL) {
		if(fileURL == null) {
			System.out.println("fileURL is not defined");
			return;
		}
		try {
			Clip clip = AudioSystem.getClip();//Obtains a clip that can be used for playing backan audio file or an audio stream
			AudioInputStream stream = AudioSystem.getAudioInputStream(fileURL);// input stream with a specified audio format andlength
			clip.open(stream);//opens the clip with the format and audio data present in the provided audioinput stream
			clip.start();
		} catch (Exception exception) {
			System.out.println("Unable to play sound: " + exception.getLocalizedMessage());
		}
	}

}
