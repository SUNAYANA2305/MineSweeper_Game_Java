
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public final class MainInterface extends JFrame{
	
	static final long serialVersionUID = 1L;
	
	//variables to set up buttons on game board
	private JMenuBar menuBar;
	private JMenu game, help;
	private JMenuItem newGame, exit,Instructions,about;
	private JRadioButton beginner, advanced, expert;
	private ButtonGroup bGroup;
	private GameBoard newBoard;
	private GameBoardConstants boardConstants;
	
	ActionHandlerClass actionHandler = new ActionHandlerClass();
	ItemHandlerClass itemHandler = new ItemHandlerClass();
	
	public MainInterface(){
		super("Minesweeper");
		boardConstants = GameBoardConstants.beginner();
		setLayout(new GridLayout(boardConstants.rows, boardConstants.columns));
		setSize(boardConstants.columns*43, boardConstants.rows*43);
		
		menuBar = new JMenuBar();//Sets the menu bar for this frame.
		setJMenuBar(menuBar);//Sets the menubar for this frame.
		game = new JMenu("Game"); //Constructs a new menu
		newGame = new JMenuItem("New game");//Creates a JMenuItem New Game
		exit = new JMenuItem("Exit");//Creates a JMenuItem exit
		game.add(newGame);//Appends a menu item to the end of this menu
		game.addSeparator();//Appends a new separator to the end of the menu
		menuBar.add(game);
		beginner = new JRadioButton("Beginner", true);
		advanced = new JRadioButton("Advanced", false);
		expert = new JRadioButton("Expert", false);
		bGroup = new ButtonGroup();
		bGroup.add(beginner);
		bGroup.add(advanced);
		bGroup.add(expert);
		game.add(beginner);
		game.add(advanced);
		game.add(expert);
		game.addSeparator();
		game.add(exit);;
		help = new JMenu("Help");
		Instructions = new JMenuItem("Instructions");
		about = new JMenuItem("About");
		help.addSeparator();
		help.add(Instructions);
		help.add(about);
		menuBar.add(help);
		menuBar.add(Box.createHorizontalGlue());
		
		newBoard = new GameBoard(boardConstants);
		menuBar.add(newBoard.falgCountLabel);
		menuBar.add(newBoard.elapsedTimeLabel);
		for(int i=0; i<boardConstants.rows; i++)
			for(int j=0; j<boardConstants.columns; j++){
				add(newBoard.GameBoard[i][j]);
			}
		
		newGame.addActionListener(actionHandler);//Adds an ActionListener to the button.
		exit.addActionListener(actionHandler);
		about.addActionListener(actionHandler);
		Instructions.addActionListener(actionHandler);
		newBoard.DialogBox.playAgain.addActionListener(actionHandler);
		newBoard.DialogBox.exit.addActionListener(actionHandler);
		beginner.addItemListener(itemHandler);//Adds an ItemListener to the checkbox.
		advanced.addItemListener(itemHandler);
		expert.addItemListener(itemHandler);
	}			
	
	void refreshGui(GameBoardConstants newConstants){
		menuBar.remove(newBoard.falgCountLabel);//remove the component from this container's layout
		menuBar.remove(newBoard.elapsedTimeLabel);
		for(int i=0; i<boardConstants.rows; i++)
			for(int j=0; j<boardConstants.columns; j++){
				remove(newBoard.GameBoard[i][j]);
			}
		boardConstants = newConstants;
		setLayout(new GridLayout(boardConstants.rows, boardConstants.columns));//sets layout with with the specified number of rows and columns
		setSize(boardConstants.columns*43, boardConstants.rows*43);//Resizes this component 
		newBoard = new GameBoard(boardConstants);
		menuBar.add(newBoard.falgCountLabel);
		menuBar.add(newBoard.elapsedTimeLabel);
		newBoard.DialogBox.playAgain.addActionListener(actionHandler);//Adds an ActionListener to the button.
		newBoard.DialogBox.exit.addActionListener(actionHandler);
		for(int i=0; i<boardConstants.rows; i++)
			for(int j=0; j<boardConstants.columns; j++){
				add(newBoard.GameBoard[i][j]);
			}
	}
	
	private class ActionHandlerClass implements ActionListener{//it is a listener interface for receiving action events
		public void actionPerformed(ActionEvent event){//Invoked when an action occurs.
			if(event.getSource()==newGame||event.getSource()==newBoard.DialogBox.playAgain){
				if(event.getSource()==newBoard.DialogBox.playAgain){
					newBoard.DialogBox.dispose();
				}
				GameBoardConstants constants = boardConstants.clone();
				refreshGui(new GameBoardConstants(1, 1, 0, -1));
				refreshGui(constants);
			}
			else if(event.getSource()==exit||event.getSource()==newBoard.DialogBox.exit){
				if(event.getSource()==newBoard.DialogBox.exit)
					newBoard.DialogBox.dispose();
				dispose();
			}
			
			
			else if(event.getSource()==Instructions){//it displays the instruction and Brings up a dialog that displays a message using
				JOptionPane.showMessageDialog(newBoard.GameBoard[boardConstants.rows/2-1][boardConstants.columns/2-1],
						"Instructions for MineSweeper\n\n" +
						"Quick Start:\n"+
						">> You are presented with a board of squares. Some squares contain mines (bombs),others don't.If you\n"+
						"click on a square containing a bomb, you lose. If you manage to click all the squares you win.\r\n"+
						">> Clicking a square which doesn't have a bomb reveals the number of neighbouring squares containing\n"+
						"bombs. Use this information plus some guess work to avoid the  bombs.\r\n"+
						">> To open a square, point at the square and click on it. To mark a square you think is a bomb, point\n"+
						"and right-click (or hover with the mouse and press Space).\n\n"+
						"Detailed Instructions:\n" +
					    ">> A squares \"neighbours\" are the squares adjacent above, below, left, right, and all 4 diagonals.\n"+
						"Squares on the sides of the board or in a corner have fewer neighbors. The board does not wrap\n"+
					    "around the edges.\r\n" + 
					    ">> If you open a square with 0 neighboring bombs, all its neighbors will automatically\n"+
					    "open. This can cause a large area to automatically open.\r\n" + 
					    ">> To remove a bomb marker from a square, point at it and right-click again.\r\n" + 
					    ">> The first square you open is never a bomb.\r\n" + 
					    ">> If you mark a bomb incorrectly, you will have to correct the mistake before you\n"+
					    "can win. Incorrect bomb marking doesn't kill you, but it can lead to mistakes which do.\r\n" + 
					    ">> You don't have to mark all the bombs to win; you just need to open all non-bomb squares.\r\n" + 
					    ">> Right-clicking twice will give you a question mark symbol which can be useful if you are\n"+
					    "unsure about a square\r\n" + 
					    ">> Click the New Game Button to start a new game.\n\n"+
					    "Status Information:\r\n" + 
					    ">> The upper left corner contains the number of bombs left to find. The number will \n"+
					    "update as you mark and unmark squares.\r\n" + 
					    ">> The upper right corner contains a time counter.\r\n"+
					    ">> Click on the time to switch to the number of moves counter. Click again to switch back to the time.\n\n" + 
					    "Options and Enhancements:\n" +
					    ">> Learning Mode - Show the contents of all unopened cells. Scores do not count towards\n"+
					    "high scores, and the Opening Move option does not apply.\r\n" + 
					    ">> Opening Move - Not only will the first square never be a bomb, but neither will any\n"+
					    "of the neighbors.\r\n" + 
					    ">> Marks (?) - Right clicking on a marked bomb will change the flag into a question mark.\n"+
					    "Right clicking again will change it back into an unmarked square.\r\n" + 
					    ">> Area Open - If an open square has the correct number of marked neighboring bombs,\n"+
					    "click on the open square to open all remaining unopened neighbor squares all at once.\n"+
					    "If an incorrect number of neighbors are marked, or all neighbors are marked or open,\n"+
					    "clicking the square has no effect. If an incorrect neighbor is marked, this will cause\n"+
					    "instant death.\r\n",
						"Instructions", JOptionPane.PLAIN_MESSAGE);
			}
			
			else if(event.getSource()==about){//message box
				JOptionPane.showMessageDialog(newBoard.GameBoard[boardConstants.rows/2-1][boardConstants.columns/2-1],
						"Minesweeper\n\n" +
						"Minesweeper is based off the original Windows version of the game\n"+
						"first released by Microsoft in 1990. Every release of Windows since\n"+ 
						"has had a version of the game.\n\n" +
					    "The history of Minesweeper goes back to the early 80's with many\n"+
						"mine-type games being released in that period. The earliest proven\n"+
					    "ancestor of Minesweeper is Mined-Out, which was released for the \n"+
						"inclair Spectrum in 1983.\n\n" +
					    "The game evolved over the 1980's into the game we love today.\n"+
						"Most of the key features like right-click (to mark a mine) and numbers\n"+
					    "(showing you adjacent bombs) evolved in the last 2-3 years \n"+
						"of the 80's.\n\n" +
					    "This browser based version is brought to you by the Free Video Games\n"+
						"Project and was originally created by Shep Poor. We think it's awesome\n"+
					    "are working to adapt it for modern devices like iPads and phones.",
						"About", JOptionPane.PLAIN_MESSAGE);
			}
		}
	}
	
	private class ItemHandlerClass implements ItemListener{//The listener interface for receiving item events

		public void itemStateChanged(ItemEvent event){//Invoked when an item has been selected or de selected by the user
			if(event.getSource()==beginner){// it displays the different gui each time selecting different levels
				refreshGui(GameBoardConstants.beginner());
			}
			else if(event.getSource()==advanced){
				refreshGui(GameBoardConstants.intermediate());
			}
			else if(event.getSource()==expert){
				refreshGui(GameBoardConstants.expert());
			}
		}
	}
}