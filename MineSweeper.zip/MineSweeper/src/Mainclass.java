
import javax.swing.JFrame;
import javax.imageio.ImageIO;

public class Mainclass {
	public static void main(String[] args){
		MainInterface mainInterface = new MainInterface();
		mainInterface.setLocation(100,100);//sets the location for the window
		mainInterface.setLocationByPlatform(true);//sets the default location for window
		mainInterface.setResizable(false);
		try{
			mainInterface.setIconImage(ImageIO.read(mainInterface.getClass().getResource("images/MinesweeperIcon.png")));// its sets the icon forthw window
		}catch(Exception e){}
		mainInterface.setVisible(true);// shows the window
		mainInterface.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//closes the window when clicked on close button
	}
}