
import javax.swing.*;
import java.awt.*;

public class DialogBox extends JDialog{
	
	static final long serialVersionUID = 1L;
	
	JButton playAgain, exit;//An implementation of a "push" button.
	JLabel DialogBoxLabel;//A display area for a short text string
	public DialogBox(){
		setLayout(new FlowLayout());//sets the layout
		setSize(300, 90);//setting width and height for layout
		setResizable(false);// disables the resizing of layout
		setAlwaysOnTop(true);//Sets the window should always be above other windows	
		setModal(true);
		DialogBoxLabel = new JLabel();
		playAgain = new JButton();//Creates a button with no set text
		exit = new JButton();
		add(DialogBoxLabel);
		add(playAgain);
		add(exit);
	}
}