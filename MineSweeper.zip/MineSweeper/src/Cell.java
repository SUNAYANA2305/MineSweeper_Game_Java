
import javax.swing.JButton;
import javax.swing.Icon;

public class Cell extends JButton{
	static final long serialVersionUID = 1L;
	
	int value, xLoc, yLoc;
	boolean flagged, clicked, pressable, marked;// boolean variables to flag click and mark in game
	String icon;
	
	Cell(int x, int y){
		xLoc = x;
		yLoc = y;
		value = 0;
		flagged = clicked = marked = false;
		pressable = true;
	}
	
	void setValue(int val){//to display values in cells
		value = val;
	}
	
	void setFlagged(boolean flag){ //to set flag on cell
		flagged = flag;
		clicked = flag;
	}
	
	void setClicked(boolean clc){ 
		clicked = clc;
	}
	
	void setPressable(boolean prb){
		pressable = prb;
	}
	
	void setMarked(boolean mrk){ // to mark ? symbol on second right click on cell
		marked = mrk;
		if(marked)
			setText("?");
		else setText("");
	}
	
	void changeIcon(Icon icn){
		setIcon(icn);
	}
	
	int getValue(){
		return value;
	}
	
	boolean isMined(){
		if(value==-1)
			return true;
		else return false;
	}
	
	boolean isFlagged(){
		return flagged;
	}
	
	boolean isClicked(){
		return clicked;
	}
	
	boolean isPressable(){
		return pressable;
	}
	
	boolean isMarked(){
		return marked;
	}
}