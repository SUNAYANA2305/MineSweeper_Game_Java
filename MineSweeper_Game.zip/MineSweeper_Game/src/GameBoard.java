/*Name: Sunayana Ambakanti
 *ID: 999901013
 *Section: 031
 *Course name: MCIS-5103
 */

import javax.swing.JLabel;
import javax.swing.Icon;
import javax.swing.Timer;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import java.util.Random;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.net.URL;

//Creates Layout(Board) for the Game
public class GameBoard { 
	
	public Cell[][] GameBoard; 
	GameBoardConstants constants;
	int falgCount, elapsedTime;
	DialogBox DialogBox; 
	JLabel falgCountLabel, elapsedTimeLabel;//display area for a short text string or an image,or both
	Random random;//used to generate a stream of pseudo random numbers
	int NumberOfClicks;
	Icon[] ArrayIcon; // fixed size picture
	boolean FirstClick;
	Timer timer;//Fires one or more ActionEvents at specified intervals
	
	public GameBoard(GameBoardConstants constants){ //constants used in gameboard
		this.constants = constants;
		FirstClick = true;
		GameBoard = new Cell[constants.rows][constants.columns];//setting rows and coloms to game board
		NumberOfClicks = 0;
		falgCount = 0;
		for(int i=0; i<constants.rows; i++)
			for(int j=0; j<constants.columns; j++)
				GameBoard[i][j] = new Cell(i, j);
		random = new Random();

		falgCountLabel = new JLabel("Mines Left: " + Integer.toString(constants.mines) + "          ");// displays the remaining number of mines during the game
		elapsedTimeLabel = new JLabel("00:00:00  ");// displays the timer
		
		DialogBox = new DialogBox();
		
		ArrayIcon = new Icon[13];//Creates ImageIcons
		ArrayIcon[0] = new ImageIcon(getClass().getResource("images/One.png"));
		ArrayIcon[1] = new ImageIcon(getClass().getResource("images/One.png"));
		ArrayIcon[2] = new ImageIcon(getClass().getResource("images/Two.png")); 
		ArrayIcon[3] = new ImageIcon(getClass().getResource("images/Three.png"));
		ArrayIcon[4] = new ImageIcon(getClass().getResource("images/Four.png"));
		ArrayIcon[5] = new ImageIcon(getClass().getResource("images/Five.png"));
		ArrayIcon[6] = new ImageIcon(getClass().getResource("images/Six.png"));
		ArrayIcon[7] = new ImageIcon(getClass().getResource("images/Seven.png"));
		ArrayIcon[8] = new ImageIcon(getClass().getResource("images/Eight.png"));
		ArrayIcon[9] = new ImageIcon(getClass().getResource("images/Mine.png"));
		ArrayIcon[10] = new ImageIcon(getClass().getResource("images/Flag.png"));
		ArrayIcon[11] = new ImageIcon(getClass().getResource("images/mine_clicked.png"));
		ArrayIcon[12] = new ImageIcon(getClass().getResource("images/WrongMine.png"));
		                                                            
		
		MouseHandlerClass MouseHandler = new MouseHandlerClass();//hadles the user interaction with mouse
		ActionHandlerClass ActionHandler = new ActionHandlerClass();//
		timer = new Timer(1000, ActionHandler);//Creates a Timer and initializes both the initial delay and between-event delay to delay milliseconds
		for(int i=0; i<constants.rows; i++)
			for(int j=0; j<constants.columns; j++){
				GameBoard[i][j].addMouseListener(MouseHandler);//Adds the specified mouse listener to receive mouse events 
				GameBoard[i][j].addActionListener(ActionHandler);//Adds an ActionListener to the button
			}
	}
	
	void addMines(int x, int y){// randomly adding mines to game
		int p, q;
		for(int i=0; i<constants.mines; i++){
			p = random.nextInt(constants.rows);
			q = random.nextInt(constants.columns);
			if(!GameBoard[p][q].isMined()&&(p!=x||q!=y)&&(p!=x-1||q!=y-1)&&(p!=x-1||q!=y)&&(p!=x-1||q!=y+1)
					&&(p!=x||q!=y-1)&&(p!=x||q!=y+1)&&(p!=x+1||q!=y-1)&&(p!=x+1||q!=y)&&(p!=x+1||q!=y+1))
				GameBoard[p][q].setValue(-1);
			else --i;
		}
	}
	
	void calcValues(){
		for(int i=0; i<constants.rows; i++){
			for(int j=0; j<constants.columns; j++){
				if(!GameBoard[i][j].isMined()){
					for(int p=-1; p<=1; p++){
						for(int q=-1; q<=1; q++){
							if((i+p)>=0&&(i+p)<constants.rows&&(j+q)>=0&&(j+q)<constants.columns){
								if(GameBoard[i+p][j+q].isMined())
									GameBoard[i][j].value++;
							}
						}
					}
				}
			}
		}
	}
	
	void showMines(int x, int y){//shows the mines on game board
		timer.stop();
		for(int i=0; i<constants.rows; i++){
			for(int j=0; j<constants.columns; j++){
				if(i==x&&j==y){
					GameBoard[i][j].setMarked(false);
					GameBoard[i][j].setIcon(ArrayIcon[11]);
				}
				else if(GameBoard[i][j].isFlagged()&&!GameBoard[i][j].isMined()){
					GameBoard[i][j].setMarked(false);
					GameBoard[i][j].setIcon(ArrayIcon[12]);
				}
				else if(GameBoard[i][j].isMined()&&!GameBoard[i][j].isFlagged()){
					GameBoard[i][j].setMarked(false);
					GameBoard[i][j].setIcon(ArrayIcon[9]);
				}
				GameBoard[i][j].setPressable(false);
				GameBoard[i][j].setFlagged(false);
				GameBoard[i][j].setClicked(true);
			}
		}
		JOptionPane.showMessageDialog(GameBoard[constants.rows/2-1][constants.columns/2-1], "Sorry! You Lost...", "", JOptionPane.PLAIN_MESSAGE);
		endGameMessage(0);
	}
	
	void triggerSetup(int x, int y){//setting trigger for wrong mine clicks
		if(!GameBoard[x][y].isClicked()){
			if(GameBoard[x][y].isMined()){
				playSound();
				showMines(x, y);
			}
			else if(GameBoard[x][y].getValue()>0){
				GameBoard[x][y].setClicked(true);
				GameBoard[x][y].setMarked(false);
				GameBoard[x][y].setIcon(ArrayIcon[GameBoard[x][y].getValue()]);
				GameBoard[x][y].setPressable(false);
				addCount();
			}
			else if(GameBoard[x][y].getValue()==0){
				GameBoard[x][y].setClicked(true);
				GameBoard[x][y].setMarked(false);
				GameBoard[x][y].setEnabled(false);
				addCount();
				for(int p=-1; p<=1; p++){
					for(int q=-1; q<=1; q++){
						if(x+p>=0&&x+p<constants.rows&&y+q>=0&&y+q<constants.columns){
							triggerSetup(x+p, y+q);
						}
					}
				}
			}
		}
	}
	
	void addCount(){
		NumberOfClicks++;
		if(NumberOfClicks==constants.rows*constants.columns){
			timer.stop();
			JOptionPane.showMessageDialog(null, "Congratulations!!", "", JOptionPane.PLAIN_MESSAGE);// pops up a message when user win the game
			endGameMessage(1);
			for(int i=0; i<constants.rows; i++){
				for(int j=0; j<constants.columns; j++){
					GameBoard[i][j].setPressable(false);
					GameBoard[i][j].setFlagged(false);
					GameBoard[i][j].setClicked(true);
				}
			}
		}
	}
	
	void setTimeLabel(int time){//sets the formatted timer on game board
		String timStr;
		timStr = String.format("%02d:%02d:%02d  ", time/3600, (time/60)%60, time%60);
		elapsedTimeLabel.setText(timStr);
		endGameIfTimeLimitReached(time);
	}
	
	void endGameIfTimeLimitReached(int elapsedTime) { // when time reaches the time limit game will be ended
		if (constants.timeLimit > 0 && elapsedTime < constants.timeLimit) {
			return;
		}
		playSound();
		showMines(0, 0);
	}
	
	void playSound() { // calling sound class
		URL url = this.getClass().getResource("/sounds/Explosion.wav");
		ExplosionSound.play(url);
	}
	
	void endGameMessage(int result){ // it displays the end game message in a message box after game end
		
		DialogBox.setLocationRelativeTo(GameBoard[constants.rows/2-1][constants.columns/2-1]);//Sets the location of the window relative to the specifiedcomponent 
		DialogBox.exit.setText("Exit");//Sets the button's text
		if(result == 0){
			DialogBox.DialogBoxLabel.setText("Sorry, You Lost!! Do you want to try again?");
			DialogBox.playAgain.setText("Try Again!!");
		}else{
			DialogBox.DialogBoxLabel.setText("Congratulations!! Do you want to play again?");
			DialogBox.playAgain.setText("Play Again!!");
		}
		DialogBox.setVisible(true);//Shows Dialog 
		
	}
	
	private class MouseHandlerClass implements MouseListener{// it receives the input from mouse
		public void mousePressed(MouseEvent event){//Invoked when a mouse button has been pressed on a component.
			Cell c;
			if(event.isMetaDown()){//Returns whether or not the Meta modifier is down on this event.
				c = (Cell)event.getSource();
				if(c.isFlagged()){
					c.setFlagged(false);
					c.setIcon(null);
					c.setMarked(true);
					c.setPressable(true);
					if(c.isMined())
						NumberOfClicks--;
					falgCount--;
					falgCountLabel.setText("Mines Left: " + Integer.toString(constants.mines-falgCount) + "          ");
				}
				else if(c.isMarked()){
					c.setMarked(false);
				}
				else if(!c.isClicked()){
					c.setFlagged(true);
					c.setText("");
					c.setIcon(ArrayIcon[10]);
					c.setPressable(false);
			
					falgCount++;
					falgCountLabel.setText("Mines Left: " + Integer.toString(constants.mines-falgCount) + "          ");
					if(c.isMined())
						addCount();
				}
			}
		}
		public void mouseEntered(MouseEvent event){//Invoked when the mouse enters a component.
			
		}
		public void mouseExited(MouseEvent event){//Invoked when the mouse enters a component.
			
		}
		public void mouseClicked(MouseEvent event){//Invoked when the mouse button has been clicked
		
		}
		public void mouseReleased(MouseEvent event){//Invoked when a mouse button has been released on a component.
			
		}
	}
	
	private class ActionHandlerClass implements ActionListener{
		public void actionPerformed(ActionEvent event){//Invoked when an action occurs.
			if(event.getSource()==timer){
				setTimeLabel(++elapsedTime);
			}
			else{
				Cell c;
				c = (Cell)event.getSource();
				if(FirstClick){
					addMines(c.xLoc, c.yLoc);
					calcValues();
					timer.start();
					FirstClick = false;
					if(c.isPressable())
						triggerSetup(c.xLoc, c.yLoc);
				}
				else{
					if(c.isPressable())
						triggerSetup(c.xLoc, c.yLoc);
				}
			}
		}
	}		
}