/*Name: Sunayana Ambakanti
 *ID: 999901013
 *Section: 031
 *Course name: MCIS-5103
 */

public final class GameBoardConstants implements Cloneable {
	public int rows;
	public int columns;
	public int mines;
	public int timeLimit;
	
	public GameBoardConstants(int rows, int columns, int mines, int timeLimit) {
		this.rows = rows;
		this.columns = columns;
		this.mines = mines;
		this.timeLimit = timeLimit;
	}
	
	public static GameBoardConstants beginner() {
		return new GameBoardConstants(7, 9, 10, 60);
	}
	
	public static GameBoardConstants intermediate() {
		return new GameBoardConstants(13, 18, 35, 180);
	}
	
	public static GameBoardConstants expert() {
		return new GameBoardConstants(22, 25, 91, 600);
	}
	
	public GameBoardConstants clone() {
		return new GameBoardConstants(this.rows, this.columns, this.mines, this.timeLimit);
	}
}
